+++para alterar a senha do postgres:
	$ sudo -u postgres psql 
	postgres=# \password postgres
	Enter new password: 
	Enter it again: 
	postgres=# \q

+++para instalar o psycopg:
	$ pip3 install psycopg2

+++para rodar o programa:
	$ ./programa.py
